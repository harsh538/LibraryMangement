package com.book.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.book.bean.BookBean;
import com.book.service.BookService;

@Controller
public class BookController {

	@Autowired
	private BookService Service;

	@RequestMapping(value = "getBooks", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<BookBean>> getBookDetails() {
		List<BookBean> list = new ArrayList<BookBean>(Service.getBooks());

		return new ResponseEntity<List<BookBean>>(list, HttpStatus.OK);
	}

	@RequestMapping(value = "addBook", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.TEXT_HTML_VALUE)
	public ResponseEntity<String> addBook(@RequestBody BookBean book) {
		int count = Service.addBook(book);
		return new ResponseEntity<String>("Book added successfully with id:" + count, HttpStatus.CREATED);
	}

	@RequestMapping(value = "updateBook", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BookBean> updateBook(@RequestBody BookBean book) {
		/*if (Service.getBooksById(book.getBookId()) == null) {
			BookBean book2 = null;
			return new ResponseEntity<BookBean>(book2, HttpStatus.INTERNAL_SERVER_ERROR);
		}*/
		BookBean updated = Service.updateBook(book);
		return new ResponseEntity<BookBean>(updated, HttpStatus.OK);
	}
}