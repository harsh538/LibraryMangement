package com.book.dao;

import java.util.Collection;

import com.book.bean.BookBean;



public interface BookDAO {

	Collection<BookBean> getBooks();

	Integer addBook(BookBean book);

	BookBean updateBook(BookBean book);


}