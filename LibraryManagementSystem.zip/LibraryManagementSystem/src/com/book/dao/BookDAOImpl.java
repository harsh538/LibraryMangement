package com.book.dao;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.book.bean.BookBean;

@Repository
public class BookDAOImpl implements BookDAO {
	
	static public Map<Integer, BookBean> map = new LinkedHashMap<Integer, BookBean>();
	static int count=4;
	static
	{
		map.put(1, new BookBean(1,"ABc","xyz","12-mAR-2021",300));
		map.put(2, new BookBean(2,"RICH","robert","1-Jan-2021",500));
		map.put(3, new BookBean(3,"paulo","david","9-Mar-2021",400));
	}
	
	public Collection<BookBean> getBooks(){
		return map.values();			
	}
	
	
	public Integer addBook(BookBean book){
		count++;
		book.setBookId(count);
		map.put(count, book);
		return count;
	}
	
	public BookBean updateBook (BookBean book){
		map.put(book.getBookId(), book);
		return book;
	}
	
}
