package com.book.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.bean.BookBean;
import com.book.dao.BookDAO;


@Service
public class BookServiceImpl implements BookService {
	
	@Autowired
	private BookDAO bookDAO;
	
	public Collection<BookBean> getBooks(){
		return bookDAO.getBooks();			
	}
	
	
	public Integer addBook(BookBean book){
		return bookDAO.addBook(book);
	}
	
	public BookBean updateBook (BookBean book){
		return bookDAO.updateBook(book);
	}
	
	
}
