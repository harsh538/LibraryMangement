package com.book.service;

import java.util.Collection;

import com.book.bean.BookBean;


public interface BookService {

	Collection<BookBean> getBooks();


	Integer addBook(BookBean book);

	BookBean updateBook(BookBean book);

}