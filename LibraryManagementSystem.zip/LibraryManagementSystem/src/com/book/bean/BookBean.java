package com.book.bean;


//@XmlRootElement
public class BookBean {
	private Integer BookId;
	private String BookName;
	private String publisher ;
	private String publisheddate;
	private Integer pages;

	public BookBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getBookId() {
		return BookId;
	}

	public void setBookId(Integer bookId) {
		BookId = bookId;
	}

	public String getBookName() {
		return BookName;
	}

	public void setBookName(String bookName) {
		BookName = bookName;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getPublisheddate() {
		return publisheddate;
	}

	public void setPublisheddate(String publisheddate) {
		this.publisheddate = publisheddate;
	}

	public Integer getPages() {
		return pages;
	}

	public void setPages(Integer pages) {
		this.pages = pages;
	}

	public BookBean(Integer bookId, String bookName, String publisher, String publisheddate, Integer pages) {
		super();
		BookId = bookId;
		BookName = bookName;
		this.publisher = publisher;
		this.publisheddate = publisheddate;
		this.pages = pages;
	}

	

	
}